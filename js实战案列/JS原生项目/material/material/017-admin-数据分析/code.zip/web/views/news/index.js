/*
 * @作者: kerwin
 */
//引入模块

import { load } from "/web/util/LoadView.js"

load("topbar-news") //加载topbar 
